package org.excel.toObject.pojo;
/**
 * 用户自定义表
 * @author lch
 *
 */
public class myExcel {
	private int id;
	private String name;//用户名
	private String code;//代码
	private String type;//类型

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
