package org.excel.toObject.servlet;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.excel.toData.code.Operation;
import org.excel.toObject.pojo.myExcel;
import org.excel.toObject.util.DBConnection;


/**
 * Servlet implementation class writeServlet
 */
@WebServlet("/writeServlet")
public class writeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor.
	 */
	public writeServlet() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			Connection c = DBConnection.getConnectin();
			c.setAutoCommit(true);
			Statement stmt = c.createStatement();
			String sql = "select t.*,t.rowid from excel_date t;";
			ResultSet rs = stmt.executeQuery(sql);
			DBConnection.close(rs);
			DBConnection.close(stmt);
			DBConnection.close(c);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// request.setAttribute("excelList", list);
		ServletContext servletContext = getServletContext();
		RequestDispatcher dispatcher = servletContext.getRequestDispatcher("/writeData.jsp");
		dispatcher.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload upload = new ServletFileUpload(factory);// 用fileupload框架

		String path = request.getSession().getServletContext().getRealPath("");
		File file = new File(path + "/checkXML/1.xml");
		List<Object> listExcelData = null;
		try {
			List<FileItem> list = upload.parseRequest(request);// 上传的所有文件

			FileItem item = list.get(0);// 获取文件
			System.out.println(item.getName());
			InputStream in = item.getInputStream();// 获得文件流

			Workbook wb = WorkbookFactory.create(in);
			Sheet sheet = wb.getSheetAt(0); // 获得一个sheet
			Operation operation = new Operation();
//			myExcel excel = null;
			boolean checkError = true;
			listExcelData  = operation.getListObject(file,sheet,"org.excel.toObject.pojo.myExcel");
			for (Object ojb : listExcelData) {
				Map<String , Object> objMap = (Map<String, Object>) ojb;
				if(!(boolean) objMap.get("checkError")){
					checkError = false;
				}
			}
			if(checkError==false){
				request.setAttribute("listExcel", listExcelData);
			}else {
				// 3.保存数据库
				Connection con = DBConnection.getConnectin();
				Statement stmt = con.createStatement();
				for (Object ojb: listExcelData) {
					Map<String , Object> objMap = (Map<String, Object>) ojb;
					myExcel excel = (myExcel) objMap.get("excelObject");
					String sql = "INSERT INTO excel_date (code,name) " + "VALUES ('" + excel.getCode() + "', '"
							+ excel.getName() + "')";
					stmt.executeUpdate(sql);
				} 
				DBConnection.close(stmt);
				DBConnection.close(con);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// 文件转换成data
		doGet(request, response);
	}
}
