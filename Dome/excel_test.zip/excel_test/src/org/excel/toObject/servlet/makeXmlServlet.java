package org.excel.toObject.servlet;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.excel.toData.bean.XmlCell;
import org.excel.toData.bean.XmlData;
import org.excel.toData.bean.XmlRule;
import org.excel.toData.bean.XmlRules;



/**
 * Servlet implementation class makeXmlServlet
 */
@WebServlet("/makeXmlServlet")
public class makeXmlServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public makeXmlServlet() {
		super();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String path = request.getSession().getServletContext().getRealPath("");
		try {
			File file = new File(path + "/checkXML/1.xml");
			JAXBContext jaxb = JAXBContext.newInstance(XmlData.class);
			Unmarshaller unm = jaxb.createUnmarshaller();
			XmlData customizer = (XmlData) unm.unmarshal(file);
			request.setAttribute("XmlClass", customizer);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ServletContext servletContext = getServletContext();
		RequestDispatcher dispatcher = servletContext.getRequestDispatcher("/makeXml.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String path = request.getSession().getServletContext().getRealPath("");
		String name = request.getParameter("name");
		String code = request.getParameter("code");
		String type = request.getParameter("type");
		XmlData xml = new XmlData();
		List<XmlCell> listCell = new ArrayList<>();
		List<XmlRule> listRule = new ArrayList<>();
		XmlCell cell = new XmlCell();
		cell.setName(name);
		cell.setCode("Name");
		XmlRules r = new XmlRules();
		XmlRule r2 = new XmlRule();
		r2.setDefaultStr("默认");
		r2.setFunction("org.excel.toObject.function.ReturnCheck.required");
		r2.setMessage("不能为空！！");
		XmlRule r3 = new XmlRule();
		r3.setDefaultStr("默认");
		r3.setFunction("org.excel.toObject.function.ReturnCheck.parse");
		Map<String, String> item = new HashMap<>();
		item.put("阿呆", "呆呆");
		item.put("阿信", "傻信");
		r3.setItem(item);
		r3.setMessage("转换错误!!");
		listRule.add(r2);
		listRule.add(r3);
		r.setXmlRule(listRule);

		cell.setXmlRules(r);
		listCell.add(cell);
		XmlCell cell1 = new XmlCell();
		cell1.setName(code);
		cell1.setCode("Code");
		listCell.add(cell1);
		XmlCell cell2 = new XmlCell();
		cell2.setName(type);
		cell2.setCode("Type");
		listCell.add(cell2);
		xml.setListXmlCell(listCell);
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		try {
			JAXBContext jc = JAXBContext.newInstance(XmlData.class);
			Marshaller m = jc.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			m.marshal(xml, os);
			String xml1 = new String(os.toByteArray(), "UTF-8");
			System.out.println(path + "/checkXML/1.xml");
			FileWriter w = new FileWriter(path + "/checkXML/1.xml");
			w.write(xml1);
			w.close();
			System.out.println(xml);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				os.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		doGet(request, response);
	}

}
