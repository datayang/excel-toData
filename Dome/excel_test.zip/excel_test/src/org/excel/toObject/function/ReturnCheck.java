package org.excel.toObject.function;

import java.util.Map;

import org.excel.toData.bean.ErrorMessage;


public class ReturnCheck {
	/**
	 * 判断是否为空
	 * name 列名，value为值, message 错误提示信息
	 * @return
	 */
	public ErrorMessage required(String name, String value,String message) {
		ErrorMessage errorMessage = new ErrorMessage();
		if ("".equals(value)) {
			errorMessage.setName(name);
			errorMessage.setMessage(message);

			return errorMessage;
		}
		errorMessage.setName(name);
		errorMessage.setMessage("true");

		return errorMessage;
	}
	
	/**
	 * 解析匹配的值
	 * 
	 * @param value
	 * @return
	 */
	public String parse(String name,Map<String, String> item, String value,String message) {
		//如果是必填项的，value1==null，把message带入到errrorMesssage类，返回
		String value1 = item.get(value);
		if (value1 != null) {
			value = value1;
		}
		return value;
	}
}
