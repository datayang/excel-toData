$(document).ready(function(){
	$("#deletec").click(function(){
		 $.get("/myExcel/deleteServlet",function(data,status){
			  if(status=="success"){
				  $("table").html($("#t_title"))
			  }
		    });
		});
	
	$("#add").click(function(){
		alert.dialog({   
		    content: '我支持HTML'  
		});  
	});
	
});